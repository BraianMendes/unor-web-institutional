# Anima App exported react code
This package was generated automatically with [Anima App](https://www.animaapp.com).
## Instructions
```
cd package_code
npm install
npm start
```
Open [http://localhost:1234](http://localhost:1234).